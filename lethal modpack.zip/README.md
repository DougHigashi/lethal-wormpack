# Modpack de Lethal Company

Modpack com alterações pra melhorar algumas funções básicas do jogo, e adicionar coisas úteis e conteúdo extra, sem alterar demais o jogo base.


# Changelog

### v1.0.0
Criando o modpack

### v1.0.1
Removendo ItemQuickSwitch, adicionando o Helmet-Cameras e atualizando o CompatibilityChecker.

#

Mods incluídos:
- **Suskitech-AlwaysHearActiveWalkies-1.4.2**
    - Ouvir Walkie-Talkies de outros jogadores por perto
- **notnotnotswipez-MoreCompany-1.7.2**
    - Aumenta o tamanho máximo da lobby
- **x753-Mimics-2.1.0**
    - Adiciona mímicos 👁
- **EladNLG-EladsHUD-1.1.0**
    - Melhora a HUD do jogo
- **granny-ScrapCalculator-1.0.1**
    - Destaca o loot mínimo para bater a cota
- **Ryokune-CompatibilityChecker-1.0.2**
    - Destaca os mods faltantes para você entrar em uma lobby
- **ATK-LaterNights-0.9.1**
    - Aumenta a duração das noites das luas
- **RugbugRedfern-Skinwalkers-2.0.1**
    - Mobs podem imitar a voz dos seus amigos
- **brigade-FreeBirdMod-1.0.0**
    - O Jester agora toca o solo de Free Bird
- **MaxWasUnavailable-ScrollInverter-1.0.0**
    - Inverte o scroll no inventário
- **RickArg-Helmet_Cameras-2.1.5**
    - Coloca a opção de ver a visão dos jogadores na nave através de uma câmera no capacete de cada jogador