# Modpack de Lethal Company

Modpack com alterações pra melhorar algumas funções básicas do jogo, e adicionar coisas úteis e conteúdo extra, sem alterar demais o jogo base.


# Changelog

### v1.0.0
Criando o modpack

#

Mods incluídos:
- **Suskitech-AlwaysHearActiveWalkies-1.4.2**
    - Ouvir Walkie-Talkies de outros jogadores por perto
- **notnotnotswipez-MoreCompany-1.7.2**
    - Aumenta o tamanho máximo da lobby
- **x753-Mimics-2.1.0**
    - Adiciona mímicos 👁
- **EladNLG-EladsHUD-1.1.0**
    - Melhora a HUD do jogo
- **granny-ScrapCalculator-1.0.1**
    - Destaca o loot mínimo para bater a cota
- **Ryokune-CompatibilityChecker-1.0.2**
    - Destaca os mods faltantes para você entrar em uma lobby 
- **vasanex-ItemQuickSwitch-1.1.0**
    - Atribui os slots do inventário para as teclas 1, 2, 3 e 4. Os emotes vão para o F1 e F2
- **ATK-LaterNights-0.9.1**
    - Aumenta a duração das noites das luas
- **RugbugRedfern-Skinwalkers-2.0.1**
    - Mobs podem imitar a voz dos seus amigos
- **brigade-FreeBirdMod-1.0.0**
    - O Jester agora toca o solo de Free Bird